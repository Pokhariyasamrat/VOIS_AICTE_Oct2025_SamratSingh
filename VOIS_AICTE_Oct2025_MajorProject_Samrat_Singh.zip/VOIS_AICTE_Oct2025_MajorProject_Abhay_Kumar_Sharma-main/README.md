# VOIS_AICTE_Oct2025_MajorProject_Abhay_Kumar_Sharma
This project focuses on analyzing Netflix’s content library to understand how its distribution of Movies and TV Shows has evolved over time. Using a dataset of 7,789 records spanning from 2008 to 2021, the study examines key attributes such as genre, country of origin, release date, and content type. 
